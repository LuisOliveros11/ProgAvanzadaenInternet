<?php
    if(isset($_POST['login']) && $_POST['login'] === "login"){
        switch ($_POST['login']) {
            case 'login':
                echo "hola";
                $email = $_POST['email'];
                $password = $_POST['contrasena'];

                
        }
    }; 

    class AuthController{
        public function login($email, $contrasena) {
            
        }
    }
?>